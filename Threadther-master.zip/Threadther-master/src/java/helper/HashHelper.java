package helper;

/* @author Jovin Angelico */
public class HashHelper {

    public static String hash (String str) {
        
        return str;
        
    }
    
}
