package controller;

/* @author Jovin Angelico */
public class TransactionCtrl {

    public Boolean checkBalance() {
        
        // Add here
        // Check balance from table customer
        return true;
        
    }
    
    public Boolean createTransaction() {
        
        // Add here
        return true;
                
    }
    
    public Boolean addTicket() {
        
        // Add here
        return true;
        
    }
}
