package controller;

/* @author Jovin Angelico */
public class CashierCtrl extends UserCtrl {

    @Override
    public Boolean buyTicket() {
        
        // Add here
        /* 
        1. Add transaction with user_id is cashier id, status = 1 (printed) 
        2. Add ticket(s) to table ticket
        */
        return true;
        
    }
    
}
