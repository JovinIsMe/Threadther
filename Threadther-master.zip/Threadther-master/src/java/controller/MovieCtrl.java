package controller;

import java.util.ArrayList;
import model.Movie;
import model.Schedule;
import model.Seat;

/* @author Jovin Angelico */
public class MovieCtrl {

    public ArrayList<Movie> showShowingMovies () {
        
        // Add here
        // Get all showing movies
        return null;
        
    }
    
    public ArrayList<Movie> showComingSoonMovies () {
        
        // Add here
        // Get all coming soon movies
        return null;
        
    }
    
    public ArrayList<Schedule> showScheduleByMovie () {
        
        // Add here
        // Get schedule by specific movie
        return null;
        
    }
    
    public ArrayList<Seat> showSeatBySchedule () {
        
        // Add here
        // Check from table ticket by available schedule
        return null;
        
    }
}
