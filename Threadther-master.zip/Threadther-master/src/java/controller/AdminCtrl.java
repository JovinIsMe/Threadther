package controller;

/* @author Jovin Angelico */
public class AdminCtrl {

    public Boolean addMovie() {
        
        // Add here
        return true;
        
    }
    
    public Boolean assignMovie() {
        
        // Add here
        return true;
        
    }
    
    public Boolean addCinema() {
        
        // Add here
        return true;
        
    }
    
    public Boolean editCinema() {
        
        // Add here
        return true;
        
    }
}
